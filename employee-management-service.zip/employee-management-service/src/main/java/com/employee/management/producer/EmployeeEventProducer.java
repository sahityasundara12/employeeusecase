package com.employee.management.producer;

import com.employee.management.dto.EmployeeEvent;
import com.employee.management.entity.MessageQueueLog;
import com.employee.management.repository.MessageQueueLogRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class EmployeeEventProducer {

    private final JmsTemplate jmsTemplate;
    private final ObjectMapper objectMapper;
    private final MessageQueueLogRepository messageQueueLogRepository;

    private static final String QUEUE_NAME = "employee.events";

    public void send(EmployeeEvent event) throws Exception {

        String payload = objectMapper.writeValueAsString(event);

        jmsTemplate.convertAndSend(
                QUEUE_NAME,
                payload
        );

        MessageQueueLog log = new MessageQueueLog();

        log.setEmployeeId(event.getEmployeeId());
        log.setQueueName(QUEUE_NAME);
        log.setPayload(payload);
        log.setDirection("SENT");
        log.setTimestamp(LocalDateTime.now());

        messageQueueLogRepository.save(log);

        System.out.println("Message Sent : " + payload);
    }
}