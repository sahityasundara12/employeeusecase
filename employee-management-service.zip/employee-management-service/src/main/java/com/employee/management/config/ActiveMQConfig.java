package com.employee.management.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;

@Configuration
@EnableJms
public class ActiveMQConfig {

    public static final String QUEUE_NAME =
            "employee.events";
}