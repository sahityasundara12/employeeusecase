package com.employee.management.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "message_queue_log")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MessageQueueLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long employeeId;

    private String queueName;

    @Lob
    private String payload;

    private String direction;

    private LocalDateTime timestamp;
}