package com.employee.management.controller;

import com.employee.management.dto.EmployeeRequest;
import com.employee.management.entity.Employee;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.XmlValidationService;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.StringReader;
import java.util.List;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;
    private final XmlValidationService xmlValidationService;

    @PostMapping(
            consumes = MediaType.APPLICATION_XML_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<Employee> createEmployee(
            @RequestBody String xml) throws Exception {

        System.out.println("Received XML:");
        System.out.println(xml);

        xmlValidationService.validate(xml);

        JAXBContext context =
                JAXBContext.newInstance(EmployeeRequest.class);

        Unmarshaller unmarshaller =
                context.createUnmarshaller();

        EmployeeRequest request =
                (EmployeeRequest) unmarshaller.unmarshal(
                        new StringReader(xml));

        Employee employee = Employee.builder()
                .name(request.getName())
                .email(request.getEmail())
                .department(request.getDepartment())
                .dateOfJoining(
                        java.time.LocalDate.parse(
                                request.getDateOfJoining()))
                .build();

        return ResponseEntity.ok(
                employeeService.create(employee));
    }

    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {

        return ResponseEntity.ok(
                employeeService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                employeeService.get(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(
            @PathVariable Long id,
            @RequestBody Employee employee) throws Exception {

        return ResponseEntity.ok(
                employeeService.update(id, employee));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(
            @PathVariable Long id) throws Exception {

        employeeService.delete(id);

        return ResponseEntity.ok(
                "Employee deleted successfully");
    }
}