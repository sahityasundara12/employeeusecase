package com.employee.management.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponse {

    private Long id;

    private String name;

    private String email;

    private String department;

    private LocalDate dateOfJoining;

    private String status;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}