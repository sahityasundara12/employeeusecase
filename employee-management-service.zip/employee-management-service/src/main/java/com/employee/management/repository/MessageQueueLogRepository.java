package com.employee.management.repository;

import com.employee.management.entity.MessageQueueLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageQueueLogRepository
        extends JpaRepository<MessageQueueLog, Long> {
}