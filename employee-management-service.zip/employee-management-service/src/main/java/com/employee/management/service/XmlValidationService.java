package com.employee.management.service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.InputStream;
import java.io.StringReader;

@Service
public class XmlValidationService {

    public void validate(String xml) throws Exception {

        InputStream xsdStream =
                new ClassPathResource("employee.xsd")
                        .getInputStream();

        SchemaFactory factory =
                SchemaFactory.newInstance(
                        XMLConstants.W3C_XML_SCHEMA_NS_URI);

        Schema schema =
                factory.newSchema(
                        new StreamSource(xsdStream));

        Validator validator =
                schema.newValidator();

        validator.validate(
                new StreamSource(
                        new StringReader(xml)));
    }
}