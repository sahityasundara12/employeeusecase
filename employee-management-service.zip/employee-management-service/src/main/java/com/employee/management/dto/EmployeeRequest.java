package com.employee.management.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.Setter;

@XmlRootElement(name = "Employee")
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
@Setter
public class EmployeeRequest {

    private String name;

    private String email;

    private String department;

    private String dateOfJoining;
}
