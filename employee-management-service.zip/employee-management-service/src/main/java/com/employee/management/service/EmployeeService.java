package com.employee.management.service;

import com.employee.management.dto.EmployeeEvent;
import com.employee.management.entity.AuditLog;
import com.employee.management.entity.Employee;
import com.employee.management.producer.EmployeeEventProducer;
import com.employee.management.repository.AuditLogRepository;
import com.employee.management.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final AuditLogRepository auditLogRepository;
    private final EmployeeEventProducer employeeEventProducer;

    public Employee create(Employee employee) throws Exception {

        Employee savedEmployee = employeeRepository.save(employee);

        saveAuditLog(savedEmployee.getId(), "CREATE", "REST");

        /*employeeEventProducer.send(
                EmployeeEvent.builder()
                        .employeeId(savedEmployee.getId())
                        .action("CREATE")
                        .timestamp(LocalDateTime.now())
                        .build()
        );*/

        return savedEmployee;
    }

    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }

    public Employee get(Long id) {

        return employeeRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Employee not found with id : " + id));
    }

    public Employee update(Long id,
                           Employee updatedEmployee) throws Exception {

        Employee existingEmployee = get(id);

        existingEmployee.setName(
                updatedEmployee.getName());

        existingEmployee.setEmail(
                updatedEmployee.getEmail());

        existingEmployee.setDepartment(
                updatedEmployee.getDepartment());

        existingEmployee.setDateOfJoining(
                updatedEmployee.getDateOfJoining());

        Employee savedEmployee =
                employeeRepository.save(existingEmployee);

        saveAuditLog(id, "UPDATE", "REST");

       /* employeeEventProducer.send(
                EmployeeEvent.builder()
                        .employeeId(id)
                        .action("UPDATE")
                        .timestamp(LocalDateTime.now())
                        .build()
        );
*/
        return savedEmployee;
    }

    public void delete(Long id) throws Exception {

        Employee employee = get(id);

        employeeRepository.delete(employee);

        saveAuditLog(id, "DELETE", "REST");

     /*   employeeEventProducer.send(
                EmployeeEvent.builder()
                        .employeeId(id)
                        .action("DELETE")
                        .timestamp(LocalDateTime.now())
                        .build()
        );*/
    }

    private void saveAuditLog(Long employeeId,
                              String action,
                              String source) {

        AuditLog auditLog = new AuditLog();

        auditLog.setEmployeeId(employeeId);
        auditLog.setAction(action);
        auditLog.setSource(source);
        auditLog.setTimestamp(LocalDateTime.now());

        auditLogRepository.save(auditLog);
    }
}