package com.employee.management.controller;

import com.employee.management.service.EmployeeService;
import com.employee.management.service.XmlValidationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class EmployeeControllerTest {

    @Mock
    private EmployeeService employeeService;

    @Mock
    private XmlValidationService xmlValidationService;

    @InjectMocks
    private EmployeeController employeeController;

    @Test
    void controllerShouldBeCreated() {
        assertNotNull(employeeController);
    }
}